PORTAL LPPM UNBARI - VERSI HTML
=================================
Lembaga Penelitian dan Pengabdian kepada Masyarakat
Universitas Batanghari Jambi
Jl. Slamet Riyadi, Broni-Jambi 36122 | lppm@unbari.ac.id

CARA BUKA LANGSUNG (OFFLINE):
1. Ekstrak file ZIP ini
2. Klik 2x file portal-lppm-unbari.html
3. Langsung terbuka di Chrome / Edge / Safari, tanpa internet

CARA JADIKAN LINK (GITHUB PAGES - GRATIS):
1. Buat akun di github.com (kalau belum punya)
2. Buat repository baru, misal: portal-lppm-unbari
3. Upload file portal-lppm-unbari.html ke repository itu
   - Klik Add file > Upload files > pilih file ini
   - Rename jadi index.html (klik file > Rename > ganti nama jadi index.html)
4. Masuk ke Settings > Pages
5. Di Branch pilih main, folder / (root), klik Save
6. Tunggu 1-2 menit, link kamu jadi:
   https://NAMA-GITHUB-KAMU.github.io/portal-lppm-unbari/
7. Bagikan link itu ke dosen / mahasiswa

AKUN DEMO:
- Admin: admin@unbari.ac.id / admin123
- Dosen: dosen@unbari.ac.id / dosen123
- Mahasiswa: mahasiswa@unbari.ac.id / mhs123

FITUR:
- Pengajuan Proposal + Upload File
- Dashboard / Tracking + Ubah Status (Admin)
- Penelitian & Pengabdian, Publikasi & Jurnal
- Pendaftaran KKN, Agenda, Profil & FAQ
- Export Rekap ke Excel (CSV)
